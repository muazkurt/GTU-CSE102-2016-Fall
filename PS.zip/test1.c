#include<stdio.h>

void main()
{
 int x,y;
 printf("Hello! This is my first C program with Ubuntu\n");
 x=10;
 y = x+5;
 printf("y=%d\n",y);


}
